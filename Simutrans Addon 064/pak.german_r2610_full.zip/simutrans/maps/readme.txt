Germany_WS: Deutschlandkarte mit allen wichtigen Wasserstra�en. Die meisten sind schiffbar, einige m��en noch per Gel�ndeabsenkung schiffbar gemacht werden. Grundwasserh�he auf 2 stellen.

Germany_DER: Deutschlandkarte mit den drei gr��ten Fl�ssen (Donau, Elbe, Rhein). Grundwasserh�he auf 2 stellen.
