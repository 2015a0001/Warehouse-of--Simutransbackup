You can put your own music files here. Edit music.tab to list them
and Simutrans will read and play them.
