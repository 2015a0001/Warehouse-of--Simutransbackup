This folder contains the base package, the executable and makeobj for the developing version of Simutrans Experimental.
Whenever something new is added AND I get around to compile, I will add new compiled versions to this folder.

Please note:
These executables are compiled from a snapshot based on the current code and might contain severe bugs. Also, I might have compiled the game in the "middle" of a new feature being implemented, so some functionality exist while other dont exist, potentially making the game unplayable. If you are having troubble with one version, try one of the other versions.
Remember that this is a work in progress and also that the balance, pakset compatibility or features may be changed without notice.

Also, any savegames saved with any of these versions might not load on other versions. Old savegames (from "original" simutrans Experimental) are probably not supported at all and used at own risk.


The source code are found here:
https://github.com/jamespetts/simutrans-experimental/tree/devel-new

Any bugs not already reported, can be reported here:
http://forum.simutrans.com/index.php?board=53.0

The executables and makeobj's are named with date compiled (yymmdd: "Simutrans-Experimental_160318.exe" is compiled 18 of march 2016), and eventual notes from me.


How to:
Get started:
- Download the folder "Simutrans-Experimental Devel-new" and all its content to your computer and put it somewhere you remember.

Get the executable:
- Choose which executable you want (preferbly the newest one), download it and put it inside the "Simutrans-Experimental Devel-new" folder you just downloaded.

Get the pakset required:
- Choose which makeobj you want (preferbly the newest one), download it and put it somewhere you remember.
- Follow the steps in the first post, second section in this thread about downloading and compiling the pakset: http://forum.simutrans.com/index.php?topic=14254.0
- Obviously, use the makeobj you downloaded from this dropbox folder instead of the linked one in the post. Also pay attention so that the name and path to the makeobj matches the name and path to "this" makeobj.
- After compiling, copy the created "pak128.britain-Ex-0.9.X" into the "Simutrans-Experimental Devel-new" folder.

Ready to go!