###################
#                 #
#     ReadMe      #
#    192comic     #
#                 #
###################

What do you need for pak192.comic?
----------------------------------

You only need the Simutrans executable for your Operating System.
You can download Simutrans on "http://simutrans.sf.net/".


Where do I find more information?
---------------------------------

German Simutrans forum: "http://www.simutrans-forum.de/forum/"!


How can I help to make this game better?
------------------------------------------

Join us in the forum, all forms of help are welcome.